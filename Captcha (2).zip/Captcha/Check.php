
<!doctype html>

<html>

<head>
<title>
Captcha
</title>

<?php include 'includes/db.inc.php'; ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



<link rel="stylesheet" href="css/bootstrap.min.css">

<style>
 @media only screen and (max-width: 600px) {
  .content
  {
  margin-top:25%;
  }

 
  }

  @media only screen and (min-width: 766px) {
  .content
  {
  margin-top:30%;
  }

 
  }

   @media only screen and (min-width: 905px) {
  .content
  {
  margin-top:5%;
  margin-left:13%;
  }

  }

   @media only screen and (min-width: 760px) {
  .content
  {
  margin-top:5%;
  margin-left:0%;
  }

  
 
  }

</style>
</head>

<body>


    <div class="content">
<?php


$QuesQueryResult=mysqli_query($conn,"select category_name,category_id from category_table order by rand() limit 1");
$QuestionRow=mysqli_fetch_assoc($QuesQueryResult);
$categid=$QuestionRow["category_id"];
$categ=$QuestionRow["category_name"];
echo ' <h5 style="color:green; text-align:center;">Which of the following words is in category ' .$QuestionRow["category_name"] . '?</h5>

<form class="form-horizontal" action="process.php" method="post">

';
$AnsQueryResult=mysqli_query($conn,"(select * FROM word_table where category_id = $categid order by rand() limit 1) UNION (select * FROM word_table where category_id <> $categid order by rand() limit 4) order by rand()");

while($AnswerRows=mysqli_fetch_array($AnsQueryResult))
	{	

?>


  <div class="container col-md-12">
   <center>

    <input type="hidden" name="categoryid" value="<?php echo $categid ?>">  
       <input type="hidden" name="category" value="<?php echo $QuestionRow["category_name"]; ?>"> 
    <label class="radio">
      <input value="<?php echo $AnswerRows["word_id"]; ?>" type="radio" name="users_choice"> <?php echo $AnswerRows["word"] ?>
    </label>
  
       
  </center>

<?php 

}


?>
  <button type="submit" id="submitAnswers" name="submit"
     style="font-size:15px; padding:0.4% 2%; margin:auto; display:block;"  class="btn btn-success">Submit Answer</button>
        
   
   
  </form>
   
 </div>
			          
</body>

</html>
