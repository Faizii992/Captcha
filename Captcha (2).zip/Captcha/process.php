<?php
   
	require 'includes/db.inc.php';
	 session_start();
	if(isset($_POST['submit']))
	{
       
		$categoryID=$_POST["categoryid"];
			$category=$_POST["category"];
		$SelectedChoice=$_POST["users_choice"];
		
$flag=1;
$queryresult=mysqli_query($conn,"SELECT word_id from word_table where category_id = $categoryID");
while($row= mysqli_fetch_assoc($queryresult))
{
$correct_choice=$row['word_id'];
if($correct_choice==$SelectedChoice)
{
	$flag=0;
    break;
}
else {
	$flag=1;
}

}


   $accessDateTime=date("Y-m-d").', '.date("l").' ' . gmdate("H:i:s", time());
  $status="";
   if($flag==1)
   {  $status="ACCESS DENIED";
   
   }
   else {
     $status="ACCESS GRANTED";
                     
}
  
    echo '<h1>'.$_SESSION['username'].'</h1>';
	    echo '<h1>'.$accessDateTime.'</h1>';
		   echo '<h1>'.$status.'</h1>';
        $result1=mysqli_query($conn,"INSERT into audit_table(username,category,status,date_time) VALUES
('$_SESSION[username]','$category','$status','$accessDateTime')");   
 }

?>


	