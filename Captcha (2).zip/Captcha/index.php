﻿
<?php
	require 'includes/db.inc.php';


    session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Index</title>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  

  <style>

  @media (min-width: 820px) {
  .section{
      margin-top:10%;
      margin-left:40%;
  }
  
  }
  .form-inline {  
  display: flex;
  flex-flow: row wrap;
  align-items: center;
}

.form-inline label {
  margin: 5px 10px 5px 0;
}

.form-inline button {
padding:1% 3%;
}

@media (max-width: 800px) {
  .form-inline input {
    margin: 10px 0;
  }

  input[type="text"]
{
margin-left:0%;
width:550px;
}
  .form-inline {
    flex-direction: column;
    align-items: stretch;
  }

  .form-inline button {
padding:1% 3%;
margin-left:40%;
}

.form-inline label {
  margin: 10px 10px 5px 10px;
}

input[type="text"]
{
margin-left:0%;
width:450px;
}
}
    
  </style>
</head>
  <?php 
if(isset($_POST['submit']))
{
  
     $_SESSION['username']=$_POST["name"];
  
header("Location:Check.php");
}

?>

<body>


   <div class="section">
 

  

  <form class="form-inline" action="index.php" method="post">
    

  
      <label for=name>Name:</label>
      <div class="col-sm-10">
        <input type="text"  class="form-control" required placeholder="Enter your name" name="name" >
          <button type="submit" id="submitmcq" name="submit"
     style="font-size:20px;"  id="submitbtn" class="btn btn-success">Enter</button>
    </div> 
     
  </form>

</div>


</body>
</html>